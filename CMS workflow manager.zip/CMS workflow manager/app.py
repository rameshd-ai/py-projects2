import os
import json
import time
import logging
from flask import Flask, render_template, request, jsonify, Response, send_from_directory
from config import PROCESSING_STEPS, UPLOAD_FOLDER, OUTPUT_FOLDER, MAX_CONTENT_LENGTH
from utils import save_job_config, generate_workflow_stream, execute_single_step

app = Flask(__name__)
app._processing_locks = {}  # Prevents concurrent runs of same job+module (e.g. htmlMenu)
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'dev-secret-key')

logging.basicConfig(level=logging.INFO)


@app.route('/')
def index():
    """Main wizard page - can accept job_id query parameter to resume a job"""
    job_id = request.args.get('job_id')
    return render_template('index.html', steps=PROCESSING_STEPS, job_id=job_id)


@app.route('/jobs')
def jobs_list():
    """Display list of all jobs"""
    return render_template('jobs_list.html')


@app.route('/api/job-config/<job_id>', methods=['GET'])
def get_job_config(job_id):
    """Get job configuration for resuming"""
    try:
        from utils import load_job_config
        
        job_config = load_job_config(job_id)
        if not job_config:
            return jsonify({"success": False, "error": "Job configuration not found"}), 404
        
        return jsonify({
            "success": True,
            "config": job_config
        })
    except Exception as e:
        logging.error(f"Error loading job config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/job-results/<job_id>', methods=['GET'])
def get_job_results(job_id):
    """Get full job results including step results"""
    try:
        from utils import get_job_folder, ensure_job_folders
        
        ensure_job_folders(job_id)
        results_file = os.path.join(get_job_folder(job_id), "results.json")
        
        if os.path.exists(results_file):
            with open(results_file, 'r', encoding='utf-8') as f:
                results = json.load(f)
                return jsonify({
                    "success": True,
                    "results": results
                })
        else:
            return jsonify({
                "success": True,
                "results": {}
            })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/job-status/<job_id>', methods=['GET'])
def get_job_status(job_id):
    """Get current status of a job including completed steps and step results"""
    try:
        from utils import get_job_folder, ensure_job_folders
        
        ensure_job_folders(job_id)
        results_file = os.path.join(get_job_folder(job_id), "results.json")
        
        if os.path.exists(results_file):
            with open(results_file, 'r', encoding='utf-8') as f:
                results = json.load(f)
                completed_steps = results.get("completed_steps", [])
                step_completion_times = results.get("step_completion_times", {})
                
                # Extract step results with status information
                step_results = {}
                step_ids = ['site_setup', 'brand_theme', 'content_plugin', 'modules_features', 'finalize']
                for step_id in step_ids:
                    if step_id in results:
                        step_data = results[step_id]
                        # Check if step was skipped
                        step_status = step_data.get("status", "success")
                        step_message = ""
                        if isinstance(step_data, dict):
                            if "result" in step_data and isinstance(step_data["result"], dict):
                                step_message = step_data["result"].get("message", "")
                            elif "message" in step_data:
                                step_message = step_data["message"]
                        
                        step_results[step_id] = {
                            "status": step_status,
                            "message": step_message,
                            "result": step_data.get("result", {}) if isinstance(step_data, dict) else {}
                        }
                
                return jsonify({
                    "success": True,
                    "completed_steps": completed_steps,
                    "step_completion_times": step_completion_times,
                    "step_results": step_results
                })
        else:
            return jsonify({
                "success": True,
                "completed_steps": [],
                "step_completion_times": {},
                "step_results": {}
            })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/save-config', methods=['POST'])
def save_config():
    try:
        data = request.get_json()
        if not data or 'job_id' not in data:
            return jsonify({"success": False, "error": "job_id is required"}), 400
        
        job_id = data['job_id']
        step_number = data.get('step_number', 0)
        
        # Save configuration
        success = save_job_config(job_id, data)
        if not success:
            return jsonify({"success": False, "error": "Failed to save"}), 500
        
        # Process the current step if step_number is provided
        if step_number > 0:
            try:
                step_result = execute_single_step(job_id, step_number)
                return jsonify({
                    "success": True,
                    "job_id": job_id,
                    "step_processed": True,
                    "step_result": step_result
                })
            except Exception as e:
                return jsonify({
                    "success": False,
                    "error": f"Step processing failed: {str(e)}"
                }), 500
        
        return jsonify({"success": True, "job_id": job_id})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/start-workflow', methods=['POST'])
def start_workflow():
    try:
        data = request.get_json()
        if not data or 'job_id' not in data:
            return jsonify({"success": False, "error": "job_id is required"}), 400
        
        job_id = data['job_id']
        save_job_config(job_id, data)
        
        return jsonify({
            "success": True,
            "job_id": job_id,
            "stream_url": f"/api/stream/{job_id}"
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/stream/<job_id>')
def stream_workflow(job_id):
    return Response(
        generate_workflow_stream(job_id),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache'}
    )


@app.route('/api/generate-report', methods=['POST'])
def generate_report():
    """Generate final completion report"""
    try:
        data = request.get_json()
        if not data or 'job_id' not in data:
            return jsonify({"success": False, "error": "job_id is required"}), 400
        
        job_id = data['job_id']
        from utils import load_job_config
        import json as json_lib
        import time
        
        from utils import get_job_folder, get_job_output_folder, ensure_job_folders
        
        # Ensure job folders exist
        ensure_job_folders(job_id)
        
        # Load all results
        results_file = os.path.join(get_job_folder(job_id), "results.json")
        if not os.path.exists(results_file):
            return jsonify({"success": False, "error": "No results found"}), 404
        
        with open(results_file, 'r', encoding='utf-8') as f:
            all_results = json.load(f)
        
        job_config = load_job_config(job_id)
        
        # Generate report
        report = {
            "job_id": job_id,
            "status": "completed",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "configuration": job_config,
            "results": {k: v for k, v in all_results.items() if k != "completed_steps"},
            "completed_steps": all_results.get("completed_steps", [])
        }
        
        report_path = os.path.join(get_job_output_folder(job_id), "report.json")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=4, ensure_ascii=False)
        
        # Return download URL with job_id in path
        return jsonify({
            "success": True,
            "report_url": f"/download/{job_id}/report.json"
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/jobs', methods=['GET'])
def get_jobs_list():
    """Get list of all jobs with their details"""
    try:
        from utils import get_job_folder, get_job_output_folder, load_job_config
        import glob
        
        jobs = []
        
        # Get all job folders from uploads directory
        if os.path.exists(UPLOAD_FOLDER):
            job_folders = [d for d in os.listdir(UPLOAD_FOLDER) 
                          if os.path.isdir(os.path.join(UPLOAD_FOLDER, d)) and d.startswith('job_')]
            
            for job_id in job_folders:
                try:
                    config_path = os.path.join(get_job_folder(job_id), "config.json")
                    results_path = os.path.join(get_job_folder(job_id), "results.json")
                    report_path = os.path.join(get_job_output_folder(job_id), "report.json")
                    
                    # Validate job folder structure - skip if config.json doesn't exist
                    if not os.path.exists(config_path):
                        logging.warning(f"Skipping job {job_id}: config.json not found (incomplete/junk record)")
                        continue
                    
                    # Get job config
                    job_config = {}
                    try:
                        with open(config_path, 'r', encoding='utf-8') as f:
                            job_config = json.load(f)
                    except (json.JSONDecodeError, IOError) as e:
                        logging.warning(f"Skipping job {job_id}: Invalid or corrupted config.json - {e}")
                        continue
                    
                    # Validate job_id format - should match pattern job_timestamp_randomstring
                    if not job_id or len(job_id) < 20 or not job_id.startswith('job_'):
                        logging.warning(f"Skipping job {job_id}: Invalid job_id format")
                        continue
                    
                    # Validate that config has at least job_id field (basic validation)
                    if not isinstance(job_config, dict):
                        logging.warning(f"Skipping job {job_id}: config.json is not a valid dictionary")
                        continue
                    
                    # Get results to check completion status
                    completed_steps = []
                    has_results = os.path.exists(results_path)
                    if has_results:
                        try:
                            with open(results_path, 'r', encoding='utf-8') as f:
                                results = json.load(f)
                                completed_steps = results.get("completed_steps", [])
                        except (json.JSONDecodeError, IOError):
                            # If results.json is corrupted, just use empty list
                            completed_steps = []
                    
                    # Get file modification time
                    folder_path = get_job_folder(job_id)
                    if os.path.exists(folder_path):
                        mod_time = os.path.getmtime(folder_path)
                        created_date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(mod_time))
                    else:
                        created_date = "Unknown"
                    
                    # Determine status
                    status = "in_progress"
                    if len(completed_steps) == len(PROCESSING_STEPS):
                        status = "completed"
                    elif len(completed_steps) > 0:
                        status = "in_progress"
                    else:
                        status = "pending"
                    
                    jobs.append({
                        "job_id": job_id,
                        "status": status,
                        "created_date": created_date,
                        "completed_steps": len(completed_steps),
                        "total_steps": len(PROCESSING_STEPS),
                        "has_report": os.path.exists(report_path),
                        "site_name": job_config.get("siteName", "N/A"),
                        "source_url": job_config.get("sourceUrl", "N/A")
                    })
                except Exception as e:
                    logging.error(f"Error processing job {job_id}: {e}")
                    continue
        
        # Sort by creation date (newest first)
        jobs.sort(key=lambda x: x.get("created_date", ""), reverse=True)
        
        return jsonify({"success": True, "jobs": jobs})
    
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/jobs/cleanup', methods=['POST'])
def cleanup_junk_jobs():
    """Remove invalid/junk job folders that don't have proper config.json"""
    try:
        from utils import get_job_folder, get_job_output_folder
        import shutil
        
        cleaned_count = 0
        cleaned_jobs = []
        failed_jobs = []
        
        # Clean up uploads folder
        if os.path.exists(UPLOAD_FOLDER):
            job_folders = [d for d in os.listdir(UPLOAD_FOLDER) 
                          if os.path.isdir(os.path.join(UPLOAD_FOLDER, d)) and d.startswith('job_')]
            
            for job_id in job_folders:
                try:
                    config_path = os.path.join(get_job_folder(job_id), "config.json")
                    folder_path = get_job_folder(job_id)
                    
                    # Check if config.json exists and is valid
                    is_junk = False
                    if not os.path.exists(config_path):
                        is_junk = True
                    else:
                        try:
                            with open(config_path, 'r', encoding='utf-8') as f:
                                job_config = json.load(f)
                            # Check if config is empty or invalid
                            if not isinstance(job_config, dict) or len(job_config) == 0:
                                is_junk = True
                            # Check job_id format
                            if not job_id or len(job_id) < 20 or not job_id.startswith('job_'):
                                is_junk = True
                        except (json.JSONDecodeError, IOError):
                            is_junk = True
                    
                    if is_junk:
                        try:
                            import stat
                            
                            def force_remove_readonly(func, path, exc_info):
                                """Error handler for Windows readonly file issues"""
                                os.chmod(path, stat.S_IWRITE)
                                func(path)
                            
                            # Delete upload folder
                            if os.path.exists(folder_path):
                                shutil.rmtree(folder_path, onerror=force_remove_readonly)
                                # Clean up any remaining empty folder
                                if os.path.exists(folder_path):
                                    try:
                                        os.rmdir(folder_path)
                                    except:
                                        pass
                            
                            # Also delete corresponding output folder if it exists
                            output_folder = get_job_output_folder(job_id)
                            if os.path.exists(output_folder):
                                shutil.rmtree(output_folder, onerror=force_remove_readonly)
                                # Clean up any remaining empty folder
                                if os.path.exists(output_folder):
                                    try:
                                        os.rmdir(output_folder)
                                    except:
                                        pass
                            
                            cleaned_count += 1
                            cleaned_jobs.append(job_id)
                            logging.info(f"Cleaned up junk job folder: {job_id}")
                        except Exception as e:
                            error_msg = f"Failed to delete junk job folder {job_id}: {e}"
                            logging.error(error_msg)
                            failed_jobs.append({"job_id": job_id, "error": str(e)})
                except Exception as e:
                    logging.error(f"Error checking job {job_id} for cleanup: {e}")
                    continue
        
        # Also clean up orphaned output folders (folders in output/ that don't have corresponding upload folders)
        if os.path.exists(OUTPUT_FOLDER):
            output_folders = [d for d in os.listdir(OUTPUT_FOLDER) 
                             if os.path.isdir(os.path.join(OUTPUT_FOLDER, d)) and d.startswith('job_')]
            
            for job_id in output_folders:
                # Check if corresponding upload folder exists
                upload_folder = get_job_folder(job_id)
                if not os.path.exists(upload_folder):
                    # Orphaned output folder - delete it
                    try:
                        import stat
                        
                        def force_remove_readonly(func, path, exc_info):
                            """Error handler for Windows readonly file issues"""
                            os.chmod(path, stat.S_IWRITE)
                            func(path)
                        
                        output_folder_path = get_job_output_folder(job_id)
                        if os.path.exists(output_folder_path):
                            shutil.rmtree(output_folder_path, onerror=force_remove_readonly)
                            # Clean up any remaining empty folder
                            if os.path.exists(output_folder_path):
                                try:
                                    os.rmdir(output_folder_path)
                                except:
                                    pass
                            cleaned_count += 1
                            cleaned_jobs.append(f"{job_id} (orphaned output)")
                            logging.info(f"Cleaned up orphaned output folder: {job_id}")
                    except Exception as e:
                        error_msg = f"Failed to delete orphaned output folder {job_id}: {e}"
                        logging.error(error_msg)
                        failed_jobs.append({"job_id": f"{job_id} (output)", "error": str(e)})
        
        response = {
            "success": True,
            "cleaned": cleaned_count,
            "cleaned_jobs": cleaned_jobs,
            "message": f"Cleaned up {cleaned_count} junk job(s)"
        }
        
        if failed_jobs:
            response["failed_jobs"] = failed_jobs
            response["message"] += f", {len(failed_jobs)} failed to delete"
        
        return jsonify(response)
    except Exception as e:
        logging.error(f"Error in cleanup: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/mark-step-complete', methods=['POST'])
def mark_step_complete():
    """Explicitly mark a step as completed and update JSON"""
    try:
        data = request.get_json()
        if not data or 'job_id' not in data or 'step_number' not in data:
            return jsonify({"success": False, "error": "job_id and step_number are required"}), 400
        
        job_id = data['job_id']
        step_number = data['step_number']
        
        from utils import get_job_folder, ensure_job_folders
        
        ensure_job_folders(job_id)
        results_file = os.path.join(get_job_folder(job_id), "results.json")
        
        # Load existing results
        if os.path.exists(results_file):
            with open(results_file, 'r', encoding='utf-8') as f:
                all_results = json.load(f)
        else:
            all_results = {}
        
        # Mark step as completed
        step_id = PROCESSING_STEPS[step_number - 1]["id"]
        all_results["completed_steps"] = all_results.get("completed_steps", [])
        if step_id not in all_results["completed_steps"]:
            all_results["completed_steps"].append(step_id)
        
        # Add completion timestamp
        if "step_completion_times" not in all_results:
            all_results["step_completion_times"] = {}
        all_results["step_completion_times"][step_id] = time.strftime("%Y-%m-%d %H:%M:%S")
        
        # Save updated results
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(all_results, f, indent=4, ensure_ascii=False)
        
        return jsonify({
            "success": True,
            "message": f"Step {step_number} marked as completed",
            "step_id": step_id
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/skip-step', methods=['POST'])
def skip_step():
    """Mark a step as skipped (without executing it) and persist status."""
    try:
        data = request.get_json()
        if not data or 'job_id' not in data or 'step_number' not in data:
            return jsonify({"success": False, "error": "job_id and step_number are required"}), 400

        job_id = data['job_id']
        step_number = data['step_number']

        from utils import get_job_folder, ensure_job_folders

        ensure_job_folders(job_id)
        results_file = os.path.join(get_job_folder(job_id), "results.json")

        # Load existing results
        if os.path.exists(results_file):
            with open(results_file, 'r', encoding='utf-8') as f:
                all_results = json.load(f)
        else:
            all_results = {}

        # Resolve step id from config
        step_id = PROCESSING_STEPS[step_number - 1]["id"]

        # Add or update step result as skipped
        all_results[step_id] = {
            "status": "skipped",
            "message": "Step skipped by user from UI"
        }

        # Ensure completed_steps includes this step
        all_results["completed_steps"] = all_results.get("completed_steps", [])
        if step_id not in all_results["completed_steps"]:
            all_results["completed_steps"].append(step_id)

        # Track skip timestamp
        if "step_completion_times" not in all_results:
            all_results["step_completion_times"] = {}
        all_results["step_completion_times"][step_id] = time.strftime("%Y-%m-%d %H:%M:%S")

        # Save updated results
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(all_results, f, indent=4, ensure_ascii=False)

        return jsonify({
            "success": True,
            "message": f"Step {step_number} ({step_id}) marked as skipped",
            "step_id": step_id
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/jobs/<job_id>', methods=['DELETE'])
def delete_job(job_id):
    """Delete a job and all its associated files"""
    try:
        from utils import get_job_folder, get_job_output_folder
        import shutil
        import stat
        
        job_upload_folder = get_job_folder(job_id)
        job_output_folder = get_job_output_folder(job_id)
        
        deleted_items = []
        errors = []
        
        def force_remove_readonly(func, path, exc_info):
            """Error handler for Windows readonly file issues"""
            os.chmod(path, stat.S_IWRITE)
            func(path)
        
        # Delete upload folder with force readonly removal
        if os.path.exists(job_upload_folder):
            try:
                shutil.rmtree(job_upload_folder, onerror=force_remove_readonly)
                deleted_items.append("upload folder")
                logging.info(f"Deleted upload folder for job {job_id}")
                
                # Verify deletion - check if folder still exists
                if os.path.exists(job_upload_folder):
                    # Try to remove any remaining empty folders
                    try:
                        os.rmdir(job_upload_folder)
                    except:
                        pass
            except Exception as e:
                error_msg = f"Failed to delete upload folder: {str(e)}"
                errors.append(error_msg)
                logging.error(f"Error deleting upload folder for job {job_id}: {e}")
        else:
            logging.warning(f"Upload folder not found for job {job_id}: {job_upload_folder}")
        
        # Delete output folder with force readonly removal
        if os.path.exists(job_output_folder):
            try:
                shutil.rmtree(job_output_folder, onerror=force_remove_readonly)
                deleted_items.append("output folder")
                logging.info(f"Deleted output folder for job {job_id}")
                
                # Verify deletion - check if folder still exists
                if os.path.exists(job_output_folder):
                    # Try to remove any remaining empty folders
                    try:
                        os.rmdir(job_output_folder)
                    except:
                        pass
            except Exception as e:
                error_msg = f"Failed to delete output folder: {str(e)}"
                errors.append(error_msg)
                logging.error(f"Error deleting output folder for job {job_id}: {e}")
        else:
            logging.warning(f"Output folder not found for job {job_id}: {job_output_folder}")
        
        if deleted_items:
            response = {
                "success": True,
                "message": f"Job {job_id} deleted successfully",
                "deleted": deleted_items
            }
            if errors:
                response["warnings"] = errors
                response["message"] += f" (with {len(errors)} warning(s))"
            return jsonify(response)
        else:
            if errors:
                return jsonify({
                    "success": False,
                    "error": "Failed to delete job folders",
                    "details": errors
                }), 500
            else:
                return jsonify({
                    "success": False,
                    "error": "Job not found"
                }), 404
            
    except Exception as e:
        logging.error(f"Error deleting job {job_id}: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/jobs/bulk-delete', methods=['POST'])
def bulk_delete_jobs():
    """Delete multiple jobs and all their associated files"""
    try:
        data = request.get_json()
        if not data or 'job_ids' not in data:
            return jsonify({"success": False, "error": "job_ids array is required"}), 400
        
        job_ids = data.get('job_ids', [])
        if not isinstance(job_ids, list) or len(job_ids) == 0:
            return jsonify({"success": False, "error": "job_ids must be a non-empty array"}), 400
        
        from utils import get_job_folder, get_job_output_folder
        import shutil
        import stat
        
        def force_remove_readonly(func, path, exc_info):
            """Error handler for Windows readonly file issues"""
            os.chmod(path, stat.S_IWRITE)
            func(path)
        
        deleted_count = 0
        failed_jobs = []
        
        for job_id in job_ids:
            try:
                job_upload_folder = get_job_folder(job_id)
                job_output_folder = get_job_output_folder(job_id)
                
                # Delete upload folder with force readonly removal
                if os.path.exists(job_upload_folder):
                    shutil.rmtree(job_upload_folder, onerror=force_remove_readonly)
                    # Clean up empty parent folder if it exists
                    if os.path.exists(job_upload_folder):
                        try:
                            os.rmdir(job_upload_folder)
                        except:
                            pass
                
                # Delete output folder with force readonly removal
                if os.path.exists(job_output_folder):
                    shutil.rmtree(job_output_folder, onerror=force_remove_readonly)
                    # Clean up empty parent folder if it exists
                    if os.path.exists(job_output_folder):
                        try:
                            os.rmdir(job_output_folder)
                        except:
                            pass
                
                deleted_count += 1
            except Exception as e:
                logging.error(f"Error deleting job {job_id}: {e}")
                failed_jobs.append({"job_id": job_id, "error": str(e)})
        
        if deleted_count > 0:
            response = {
                "success": True,
                "deleted_count": deleted_count,
                "message": f"Successfully deleted {deleted_count} job(s)"
            }
            if failed_jobs:
                response["failed_jobs"] = failed_jobs
                response["message"] += f", {len(failed_jobs)} failed"
            return jsonify(response)
        else:
            return jsonify({
                "success": False,
                "error": "No jobs were deleted",
                "failed_jobs": failed_jobs
            }), 500
            
    except Exception as e:
        logging.error(f"Error in bulk delete: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/download/<job_id>/<filename>')
def download_file(job_id, filename):
    """Download file from job-specific folder"""
    try:
        from utils import get_job_output_folder
        job_output_folder = get_job_output_folder(job_id)
        return send_from_directory(job_output_folder, filename, as_attachment=True)
    except FileNotFoundError:
        return jsonify({"success": False, "error": "File not found"}), 404


@app.route('/api/menu-config/<config_type>', methods=['GET'])
def get_menu_config(config_type):
    """Get menu configuration file (template or mapper)"""
    try:
        from config import BASE_DIR
        resource_dir = os.path.join(BASE_DIR, "resource")
        
        if config_type == 'template':
            file_path = os.path.join(resource_dir, "menu_payload_template.json")
        elif config_type == 'mapper':
            file_path = os.path.join(resource_dir, "menu_field_mapper.json")
        else:
            return jsonify({"success": False, "error": "Invalid config type"}), 400
        
        if not os.path.exists(file_path):
            return jsonify({"success": False, "error": "Configuration file not found"}), 404
        
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return jsonify({
            "success": True,
            "data": data
        })
    except Exception as e:
        logging.error(f"Error loading menu config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/menu-config/<config_type>', methods=['POST'])
def save_menu_config(config_type):
    """Save menu configuration file (template or mapper)"""
    try:
        from config import BASE_DIR
        resource_dir = os.path.join(BASE_DIR, "resource")
        
        if config_type == 'template':
            file_path = os.path.join(resource_dir, "menu_payload_template.json")
        elif config_type == 'mapper':
            file_path = os.path.join(resource_dir, "menu_field_mapper.json")
        else:
            return jsonify({"success": False, "error": "Invalid config type"}), 400
        
        data = request.get_json()
        if not data or 'data' not in data:
            return jsonify({"success": False, "error": "Missing data in request"}), 400
        
        # Ensure resource directory exists
        os.makedirs(resource_dir, exist_ok=True)
        
        # Save the configuration
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data['data'], f, indent=2, ensure_ascii=False)
        
        logging.info(f"Menu {config_type} configuration saved successfully")
        return jsonify({
            "success": True,
            "message": f"{config_type} configuration saved successfully"
        })
    except json.JSONDecodeError as e:
        return jsonify({"success": False, "error": f"Invalid JSON: {str(e)}"}), 400
    except Exception as e:
        logging.error(f"Error saving menu config: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/process-sub-process', methods=['POST'])
def process_sub_process():
    """
    Process a specific sub-process module (e.g., FAQ Manager, Dine Menu)
    """
    try:
        from utils import load_job_config
        
        data = request.get_json()
        if not data or 'job_id' not in data or 'module_id' not in data:
            return jsonify({"success": False, "error": "job_id and module_id are required"}), 400
        
        job_id = data['job_id']
        module_id = data['module_id']
        form_data = data.get('form_data', {})
        
        # Load job configuration (or use form_data as fallback)
        job_config = load_job_config(job_id)
        
        # If job config doesn't exist or is empty, use form_data
        if not job_config:
            job_config = form_data.copy() if form_data else {}
        
        # Merge form_data into job_config to ensure latest values
        if form_data:
            job_config.update(form_data)
        
        # Ensure job_id is set
        job_config['job_id'] = job_id
        
        # Save the configuration if it was updated
        if form_data:
            from utils import save_job_config
            save_job_config(job_id, job_config)
        
        # Create workflow context
        workflow_context = {
            "job_config": job_config,
            "job_id": job_id
        }
        
        # Prevent concurrent processing of same job+module (avoids duplicate records)
        lock_key = f"{job_id}:{module_id}"
        if lock_key in app._processing_locks:
            logging.warning(f"Rejected concurrent request for {lock_key} - already processing")
            return jsonify({
                "success": False,
                "error": f"Already processing {module_id} for this job. Please wait."
            }), 429
        app._processing_locks[lock_key] = True
        
        try:
            # Load previous step results (including site_setup, brand_theme, etc.)
            from utils import get_job_folder
            import os
            results_file = os.path.join(get_job_folder(job_id), "results.json")
            if os.path.exists(results_file):
                try:
                    with open(results_file, 'r', encoding='utf-8') as f:
                        previous_results = json.load(f)
                        workflow_context.update(previous_results)
                    logging.info(f"Loaded previous step results for job {job_id}")
                except Exception as e:
                    logging.warning(f"Could not load previous results for job {job_id}: {e}")
            
            # Process based on module_id
            result = None
            if module_id == 'htmlMenu':
                from processing_steps.html_menu import run_html_menu_step
                step_config = {"delay": 1}
                result = run_html_menu_step(job_id, step_config, workflow_context)
            elif module_id == 'htmlMenuSecondary':
                from processing_steps.secondary_language_menu import run_secondary_language_menu_step
                lang_key = data.get('lang_key')  # optional: 'lang1', 'lang2', 'lang3'
                reprocess_only = data.get('reprocess_only', False)
                result = run_secondary_language_menu_step(job_id, lang_key=lang_key, reprocess_only=reprocess_only)
                job_config = load_job_config(job_id)
            elif module_id == 'faqManager':
                source_link = data.get('source_link')
                if not source_link:
                    return jsonify({"success": False, "error": "source_link is required for FAQ processing"}), 400
                from processing_steps.faq_manager import process_faq_from_source_link
                workflow_context["source_link"] = source_link
                result = process_faq_from_source_link(job_id, source_link)
            else:
                return jsonify({"success": False, "error": f"Unknown module_id: {module_id}"}), 400
            
            if result and result.get("success", True):
                from utils import save_job_config
                if 'processed_modules' not in job_config:
                    job_config['processed_modules'] = {}
                job_config['processed_modules'][module_id] = True
                job_config['processed_modules'][f"{module_id}_timestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")
                if module_id == 'htmlMenuSecondary':
                    if 'processed_secondary_languages' not in job_config:
                        job_config['processed_secondary_languages'] = {}
                    lang_key = data.get('lang_key')
                    if lang_key:
                        job_config['processed_secondary_languages'][lang_key] = True
                    else:
                        sec = job_config.get('secondaryLanguage') or {}
                        for k in ('lang1', 'lang2', 'lang3'):
                            if (sec.get(k) or {}).get('sourceUrl'):
                                job_config['processed_secondary_languages'][k] = True
                save_job_config(job_id, job_config)
                logging.info(f"Marked {module_id} as processed for job {job_id}")
                return jsonify({"success": True, "module_id": module_id, "result": result})
            else:
                return jsonify({
                    "success": False,
                    "error": result.get("error", "Processing failed") if result else "Processing failed"
                }), 500
        finally:
            app._processing_locks.pop(lock_key, None)
            
    except Exception as e:
        logging.error(f"Error processing sub-process: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route('/api/download-faq-file', methods=['GET'])
def download_faq_file():
    """
    Download FAQ output file
    """
    try:
        from utils import get_job_output_folder
        from flask import send_file
        
        job_id = request.args.get('job_id')
        file_name = request.args.get('file_name')  # Just the filename
        
        if not job_id or not file_name:
            return jsonify({"success": False, "error": "job_id and file_name are required"}), 400
        
        # Get the file path from job output folder
        output_dir = get_job_output_folder(job_id)
        file_path = os.path.join(output_dir, file_name)
        
        if not os.path.exists(file_path):
            return jsonify({"success": False, "error": "File not found"}), 404
        
        return send_file(file_path, as_attachment=True, download_name=file_name)
        
    except Exception as e:
        logging.error(f"Error downloading FAQ file: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

