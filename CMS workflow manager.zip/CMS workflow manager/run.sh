#!/bin/bash

echo "Starting CMS Workflow Manager..."
echo ""
echo "Using Poetry environment..."
poetry run python app.py










